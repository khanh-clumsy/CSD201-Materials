package Controller;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author admin
 */
public class Validate {

    private final static Scanner sc = new Scanner(System.in);

    private Validate() {
    }

    public static String getString(String msgInfo, String msgError, String REGEX) {
        do {
            System.out.print(msgInfo);
            String str = sc.nextLine();
            if (str.matches(REGEX)) {
                return str;
            } else {
                System.out.println(msgError);
            }

        } while (true);
    }

    public static int getInt(String msgInfo, String msgErrorOutOfRange, String msgErrorNumber, int min, int max) {
        do {
            try {
                System.out.print(msgInfo);
                int number = Integer.parseInt(sc.nextLine());
                if (number >= min && number <= max) {
                    return number;
                } else {
                    System.out.println(msgErrorOutOfRange);
                }

            } catch (NumberFormatException e) {
                System.out.println(msgErrorNumber);
            }
        } while (true);
    }

    public static int getDouble(String msgInfo, String msgErrorOutOfRange, String msgErrorNumber, double min, double max) {
        do {
            try {
                System.out.print(msgInfo);
                int number = Integer.parseInt(sc.nextLine());
                if (number >= min && number <= max) {
                    return number;
                } else {
                    System.out.println(msgErrorOutOfRange);
                }

            } catch (NumberFormatException e) {
                System.out.println(msgErrorNumber);
            }
        } while (true);
    }
}
