package Controller;

import Manager.CustomerList;
import Manager.ProductList;
import Manager.OrderList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        ProductList productList = new ProductList();
        CustomerList customerList = new CustomerList();
        OrderList orderList = new OrderList();
        boolean exit = false;

        while (!exit) {
            System.out.println("====== Sale Management System ======");
            System.out.println("1. Product");
            System.out.println("2. Customer");
            System.out.println("3. Order");
            System.out.println("0. Exit");
            int choice = Validate.getInt("Enter your choice: ", "Out of range!", "Invalid format!", 0, 3);
            switch (choice) {
                case 1:
                    productMenu(productList, customerList, orderList);
                    break;
                case 2:
                    customerMenu(productList, customerList, orderList);
                    break;
                case 3:
                    orderMenu(productList, customerList, orderList);
                    break;
                case 0:
                    exit = true;
                    System.out.println("Exiting program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        sc.close();
    }

    public static void productMenu(ProductList productList, CustomerList customerList, OrderList orderList) throws Exception {
        boolean back = false;
        while (!back) {
            System.out.println("====== Product Menu ======");
            System.out.println("1. Load data from file");
            System.out.println("2. Input and add to the end of list");
            System.out.println("3. Display data");
            System.out.println("4. Save product list to file");
            System.out.println("5. Search by pcode");
            System.out.println("6. Delete by pcode");
            System.out.println("7. Sort by ascending order of pcode");
            System.out.println("8. Input and add to the begin of list");
            System.out.println("9. Add before position k");
            System.out.println("10. Delete at position k");
            System.out.println("11. Search by name");
            System.out.println("12. Search ordered by pcode");
            int choice = Validate.getInt("Enter your choice: ", "Out of range!", "Invalid format!", 0, 12);

            switch (choice) {
                case 1:
                    productList.f1_loadDataFromFile("products.txt");
                    break;
                case 2:
                    productList.f2_inputAndAddToEnd();
                    break;
                case 3:
                    productList.f3_displayData();
                    break;
                case 4:
                    productList.f4_saveToFile("products.txt");
                    break;
                case 5:
                    String pcode = Validate.getString("Enter pcode to search: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    productList.f5_searchByPcode(pcode);
                    break;
                case 6:
                    pcode = Validate.getString("Enter pcode to search: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    productList.f6_deleteByPcode(pcode);
                    break;
                case 7:
                    productList.f7_sortByPcodeAscending();
                    break;
                case 8:
                    productList.f8_inputAndAddToBegin();
                    break;
                case 9:
                    int pos = Validate.getInt("Enter position to add before that pos: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
                    productList.f9_addBeforePos(pos);
                    break;
                case 10:
                    pos = Validate.getInt("Enter position to delete: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
                    productList.f10_deleteAtPosK(pos);
                    break;
                case 11:
                    String name = Validate.getString("Enter name to search: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    productList.f11_searchByName(name);
                    break;
                case 12:
                    pcode = Validate.getString("Enter pcode to search ordered: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    productList.f12_searchOrderedByPcode(pcode, customerList, orderList);
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void customerMenu(ProductList productList, CustomerList customerList, OrderList orderList) throws Exception {
        boolean back = false;
        while (!back) {
            System.out.println("====== Customer Menu ======");
            System.out.println("1. Load data from file");
            System.out.println("2. Input and add to end");
            System.out.println("3. Display data");
            System.out.println("4. Save to file");
            System.out.println("5. Search by ccode");
            System.out.println("6. Delete by ccode");
            System.out.println("7. Search by name");
            System.out.println("8. Search not shipped products by ccode");
            System.out.println("0. Back to Main Menu");
            int choice = Validate.getInt("Enter your choice: ", "Out of range!", "Invalid format!", 0, 8);

            switch (choice) {
                case 1:
                    customerList.f1_loadDataFromFile("customers.txt");
                    break;
                case 2:
                    customerList.f2_inputAndAddToEnd();
                    break;
                case 3:
                    customerList.f3_displayData();
                    break;
                case 4:
                    customerList.f4_saveToFile("customers.txt");
                    break;
                case 5:
                    String ccode = Validate.getString("Enter ccode to search: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    customerList.f5_searchByCcode(ccode);
                    break;
                case 6:
                    ccode = Validate.getString("Enter ccode to delete: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    customerList.f6_deleteByCcode(ccode);
                    break;
                case 7:
                    ccode = Validate.getString("Enter ccode to search name: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    customerList.f7_searchByName(ccode);
                    break;
                case 8:
                    ccode = Validate.getString("Enter ccode to search order not shipped yet: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    customerList.f8_searchNotShippedProductByCcode(ccode, productList, orderList);
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void orderMenu(ProductList productList, CustomerList customerList, OrderList orderList) throws Exception {
        boolean back = false;
        while (!back) {
            System.out.println("====== Order Menu ======");
            System.out.println("1. Load data from file");
            System.out.println("2. Order book");
            System.out.println("3. Display orders");
            System.out.println("4. Save orders to file");
            System.out.println("5. Sort by pocde and ccode");
            System.out.println("6. Ship order by pocde and ccode");
            System.out.println("0. Back to Main Menu");
            int choice = Validate.getInt("Enter your choice: ", "Out of range!", "Invalid format!", 0, 6);

            switch (choice) {
                case 1:
                    orderList.f1_loadDataFromFile("orders.txt");
                    break;
                case 2:
                    orderList.f2_orderBook(productList, customerList);
                    break;
                case 3:
                    orderList.f3_displayData(productList);
                    break;
                case 4:
                    orderList.f4_saveToFile("orders.txt");
                    break;
                case 5:
                    orderList.f5_sortByPcodeAndCcode(productList, customerList);
                    break;
                case 6:
                    String pcode = Validate.getString("Enter pcode: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    String ccode = Validate.getString("Enter ccode: ", "Error!", "^[a-zA-Z0-9 ]+$");
                    orderList.f6_shipOrderByPcodeAndCcode(pcode, ccode, productList, customerList);
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
