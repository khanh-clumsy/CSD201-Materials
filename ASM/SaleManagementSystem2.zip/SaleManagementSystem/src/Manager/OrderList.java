/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import Controller.Validate;
import Model.Order;
import Model.Customer;
import Model.Product;
import Node.Node;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author admin
 */
public class OrderList {

    Node head, tail;

    public OrderList() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addLast(Order x) {
        Node newNode = new Node(x);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            tail = newNode;
        }
    }

    public void f1_loadDataFromFile(String fname) throws FileNotFoundException, IOException, Exception {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        FileReader fr = new FileReader(fname);
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            String[] arr = line.trim().split(",");
            String pcode = arr[0].trim();
            String ccode = arr[1].trim();
            Date odate = null;
            Date sdate = null;
            try {
                odate = dateFormat.parse(arr[2].trim());
                sdate = dateFormat.parse(arr[3].trim());
            } catch (ParseException e) {
                System.out.println(e.getMessage());
            }
            int quantity = Integer.parseInt(arr[4].trim());
            Order x = new Order(pcode, ccode, odate, sdate, quantity);
            addLast(x);
        }
        System.out.println("Load file successfully!");
        br.close();
        fr.close();
    }

    public void f2_orderBook(ProductList prodList, CustomerList cusList) throws Exception {
        String pcode = Validate.getString("Enter pcode: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String ccode = Validate.getString("Enter ccode: ", "Error!", "^[a-zA-Z0-9 ]+$");
        Product product = prodList.f5_searchByPcode(pcode);
        Customer customer = cusList.f5_searchByCcode(ccode);
        if (product == null) {
            System.out.println("Product not found!");
            return;
        }

        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }
        int orderQuantity = Validate.getInt("Enter quantity to order: ", "Out of range!", "Invalid format!", 1, product.getQuantity());
        Date odate = new Date();
        Date sdate = null;
        Order order = new Order(pcode, ccode, odate, sdate, orderQuantity);
        //Add
        addLast(order);
        System.out.println("Ordered successfully!");
        //Subtract
        product.setQuantity(product.getQuantity() - orderQuantity);
        product.setSaled(product.getSaled() + orderQuantity);
    }

    public void f3_displayData(ProductList productList) {
        if (isEmpty()) {
            System.out.println("No orders to display!");
            return;
        }

        System.out.println(String.format("%-5s %-5s %-15s %-15s %-15s %-10s %-10s",
                "Pcode", "Ccode", "Order Date", "Ship Date", "Quantity", "Price", "Total Value"));

        Node p = head;
        while (p != null) {
            Order order = (Order) p.info;
            Product product = productList.f5_searchByPcode(order.getPcode());

            if (product != null) {
                double totalValue = product.getPrice() * order.getQuantity();
                System.out.printf("%-5s %-5s %-15s %-15s %-15d %-10.2f %-10.2f\n",
                        order.getPcode(),
                        order.getCcode(),
                        order.getOdate(),
                        order.getSdate(),
                        order.getQuantity(),
                        product.getPrice(),
                        totalValue);
            } else {
                System.out.println("Product not found for order with Pcode: " + order.getPcode());
            }
            p = p.next;
        }
        System.out.println();
    }

    public void f4_saveToFile(String fname) throws IOException {
        FileWriter fw = new FileWriter(fname);
        BufferedWriter bw = new BufferedWriter(fw);
        Node p = head;
        while (p != null) {
            Order order = (Order) p.info;
            bw.write(String.format("%s,%s,%s,%s,%d", order.getPcode(), order.getCcode(),
                    order.getOdate(), order.getSdate(), order.getQuantity()));
            bw.newLine();
            p = p.next;
        }
        bw.close();
        fw.close();
    }

    public Order searchOrderByCcode(String ccode) {
        Node p = head;
        while (p != null) {
            Order order = (Order) p.info;
            if (order.getCcode().equalsIgnoreCase(ccode)) {
                return order;
            }
            p = p.next;
        }
        return null;
    }

    public void f5_sortByPcodeAndCcode(ProductList productList, CustomerList customerList) {
        if (isEmpty()) {
            System.out.println("No orders to sort!");
            return;
        }

        for (Node i = head; i.next != null; i = i.next) {
            for (Node j = head; j.next != null; j = j.next) {
                Order order1 = (Order) j.info;
                Order order2 = (Order) j.next.info;
                if (order1.getPcode().compareTo(order2.getPcode()) < 0) {
                    Order temp = order1;
                    order1 = order2;
                    order2 = temp;
                } else if (order1.getPcode().equals(order2.getPcode())
                        && order1.getCcode().compareTo(order2.getCcode()) < 0) {
                    Order temp = order1;
                    order1 = order2;
                    order2 = temp;
                }
            }
        }
        System.out.println("Sorted!");
    }

    public void f6_shipOrderByPcodeAndCcode(String pcode, String ccode, ProductList productList, CustomerList customerList) {
        Node p = head;
        boolean orderFound = false;
        while (p != null) {
            Order order = (Order) p.info;
            if (order.getPcode().equalsIgnoreCase(pcode) && order.getCcode().equalsIgnoreCase(ccode)) {
                orderFound = true;
                if (order.getSdate() == null) {
                    order.setSdate(new Date());
                    System.out.println("Order shipped successfully.");
                    System.out.println("Shipping date set to: " + order.getSdate());
                } else {
                    System.out.println("Order has already been shipped.");
                }
                break;
            }
            p = p.next;
        }

        if (!orderFound) {
            System.out.println("Order not found with pcode: " + pcode + " and ccode: " + ccode);
        }
    }
}
