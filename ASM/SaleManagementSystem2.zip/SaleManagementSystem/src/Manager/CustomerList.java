package Manager;

import Controller.Validate;
import Model.Customer;
import Model.Order;
import Model.Product;
import Node.Node;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author admin
 */
public class CustomerList {

    Node head, tail;

    public CustomerList() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public boolean isExistCcode(String ccode) {
        Node p = head;
        while (p != null) {
            Customer cus = (Customer) p.info;
            if (cus.getCcode().equalsIgnoreCase(ccode)) {
                return true;
            }
            p = p.next;
        }
        return false;

    }

    public void addLast(Customer x) {
        Node newNode = new Node(x);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            tail = newNode;
        }
    }

    public void f1_loadDataFromFile(String fname) throws FileNotFoundException, IOException, Exception {
        FileReader fr = new FileReader(fname);
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            String[] arr = line.trim().split(",");
            String ccode = arr[0].trim();
            String name = arr[1].trim();
            String phone = arr[2].trim();
            Customer x = new Customer(ccode, name, phone);
            addLast(x);
        }
        System.out.println("Load file successfully!");
        br.close();
        fr.close();
    }

    public void f2_inputAndAddToEnd() throws Exception {
        String ccode;
        do {
            ccode = Validate.getString("Enter ccode: ", "Error!", "^[a-zA-Z0-9 ]+$");
            if (isExistCcode(ccode)) {
                System.out.println("Code is exist! Enter again!");
            } else {
                break;
            }
        } while (true);
        String name = Validate.getString("Enter name: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String phone = Validate.getString("Enter phone number: ", "Error!", "^[0-9]+$");
        Customer c = new Customer(ccode, name, phone);
        addLast(c);
        System.out.println("Added successfully!");
    }

    public void f3_displayData() {
        Node p = head;
        System.out.println(String.format("%-10s %-20s %-15s", "Ccode", "Name", "Phone Number"));
        while (p != null) {
            System.out.println(p.info.toString());
            p = p.next;
        }
        System.out.println();
    }

    public void f4_saveToFile(String fname) throws IOException {
        FileWriter fw = new FileWriter(fname);
        BufferedWriter bw = new BufferedWriter(fw);
        Node current = head;
        while (current != null) {
            Customer cus = (Customer) current.info;
            bw.write(String.format("%s,%s,%s",
                    cus.getCcode(), cus.getName(), cus.getPhone()));
            bw.newLine();
            current = current.next;
        }
        bw.close();
        fw.close();
    }

    public Customer f5_searchByCcode(String ccode) {
        Node p = head;
        while (p != null) {
            Customer customer = (Customer) p.info;
            if (customer.getCcode().equalsIgnoreCase(ccode)) {
                return customer;
            }
            p = p.next;
        }
        return null;
    }

    public void deleteFirst() {
        if (!isEmpty()) {
            if (head.next == null) {
                head = tail = null;
            } else {
                head = head.next;
            }
        }
    }

    public void deleteLast() {
        Node current = head;
        if (isEmpty()) {
            System.out.println("List is empty!");
        } else if (head.next == null) {
            head = null;
        } else {
            while (current.next.next != null) {
                current = current.next;
            }
            current.next = null;
            tail = current;
        }
    }

    public int countElement() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public void delNodeAtPos(int pos) {
        if (!isEmpty() && pos >= 0 && pos < countElement()) {
            Node p = head;
            int count = 0;
            if (pos == 0) {
                deleteFirst();
            } else if (pos == countElement() - 1) {
                deleteLast();
            } else {
                while (p != null) {
                    if (count == pos - 1) {
                        p.next = p.next.next;
                        return;
                    }
                    count++;
                    p = p.next;
                }
            }
        }
    }

    public void f6_deleteByCcode(String ccode) {
        Node p = head;
        int count = 0;
        while (p != null) {
            Customer cus = (Customer) p.info;
            if (cus.getCcode().equalsIgnoreCase(ccode)) {
                delNodeAtPos(count);
                break;
            }
            p = p.next;
            count++;
        }
    }

    public void f7_searchByName(String name) {
        Node p = head;
        System.out.print(String.format("%-10s %-20s %-15s\n", "Ccode", "Name", "Phone Number"));
        while (p != null) {
            Customer cus = (Customer) p.info;
            if (cus.getName().equalsIgnoreCase(name)) {
                System.out.println(p.info.toString());
                break;
            }
            p = p.next;
        }
    }

    public void f8_searchNotShippedProductByCcode(String ccode, ProductList productList, OrderList orderList) {
        Customer customer = f5_searchByCcode(ccode);
        Node p = orderList.head;
        if (customer != null) {
            System.out.println("Customer found: ");
            System.out.println(String.format("%-10s %-20s %-15s", "Ccode", "Name", "Phone Number"));
            System.out.println(customer.toString());
            boolean hasNotShipped = false;
            while (p != null) {
                Order order = orderList.searchOrderByCcode(ccode);
                if (order.getSdate().equalsIgnoreCase("Not shipped")) {
                    hasNotShipped = true;
                    Product product = productList.f5_searchByPcode(order.getPcode());
                    if (product != null) {
                        System.out.println("Product found: ");
                        System.out.println(String.format("%-5s %-15s %-10s %-10s %-15s %-10s %-10s %-8s", "Pcode", "Name", "Maker", "Unit", "Category", "Quantity", "Saled", "Price"));
                        System.out.println(product.toString());
                    }
                }
                p = p.next;
            }

            if (!hasNotShipped) {
                System.out.println("No order has not shipped to customer!");
            }
        } else {
            System.out.println("Not found customer with ccode: " + ccode);
        }
    }
}
