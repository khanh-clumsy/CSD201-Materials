package Manager;

import Controller.Validate;
import Model.Customer;
import Model.Order;
import Model.Product;
import Node.Node;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author admin
 */
public class ProductList {

    Node head, tail;

    public ProductList() {
        head = tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addLast(Product x) {
        Node newNode = new Node(x);
        if (isEmpty()) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            tail = newNode;
        }
    }

    public boolean isExistPcode(String otherPcode) {
        Node p = head;
        while (p != null) {
            if (((Product) p.info).getPcode().equalsIgnoreCase(otherPcode)) {
                return true;
            }
            p = p.next;
        }
        return false;
    }

    public void f1_loadDataFromFile(String fname) throws FileNotFoundException, IOException, Exception {
        FileReader fr = new FileReader(fname);
        BufferedReader br = new BufferedReader(fr);
        String line;
        while ((line = br.readLine()) != null) {
            String[] arr = line.trim().split(",");
            String pcode = arr[0].trim();
            String name = arr[1].trim();
            String maker = arr[2].trim();
            String unit = arr[3].trim();
            String category = arr[4].trim();
            int quantity = Integer.parseInt(arr[5].trim());
            int saled = Integer.parseInt(arr[6].trim());
            double price = Double.parseDouble(arr[7].trim());
            Product x = new Product(pcode, name, maker, unit, category, quantity, saled, price);
            addLast(x);
        }
        System.out.println("Load file successfully!");
        br.close();
        fr.close();
    }

    public void f2_inputAndAddToEnd() throws Exception {
        String pcode = Validate.getString("Enter pcode: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String name = Validate.getString("Enter name: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String maker = Validate.getString("Enter maker: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String unit = Validate.getString("Enter unit: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String category = Validate.getString("Enter category: ", "Error!", "^[a-zA-Z0-9 ]+$");
        int quantity = Validate.getInt("Enter quanity: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
        int saled;
        do {
            saled = Validate.getInt("Enter saled: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
            if (saled <= quantity) {
                break;
            } else {
                System.out.println("Enter saled again (Saled <= Quantity): ");
            }
        } while (true);
        double price = Validate.getDouble("Enter price: ", "Out of range!", "Invalid format!", 0, Double.MAX_VALUE);
        Product p = new Product(pcode, name, maker, unit, category, quantity, saled, price);
        addLast(p);
        System.out.println("Added last successfully!");
    }

    public void f3_displayData() {
        Node p = head;
        System.out.println(String.format("%-5s %-15s %-10s %-10s %-15s %-10s %-10s %-8s", "Pcode", "Name", "Maker", "Unit", "Category", "Quantity", "Saled", "Price"));
        while (p != null) {
            System.out.println(p.info.toString());
            p = p.next;
        }
        System.out.println();
    }

    public void f4_saveToFile(String fname) throws IOException {
        FileWriter fw = new FileWriter(fname);
        BufferedWriter bw = new BufferedWriter(fw);
        Node current = head;
        while (current != null) {
            Product p = (Product) current.info;
            bw.write(String.format("%s,%s,%s,%s,%s,%d,%d,%.2f",
                    p.getPcode(), p.getName(), p.getMaker(), p.getUnit(),
                    p.getCategory(), p.getQuantity(), p.getSaled(), p.getPrice()));
            bw.newLine();
            current = current.next;
        }
        bw.close();
        fw.close();
    }

    public Product f5_searchByPcode(String pcode) {
        Node p = head;
        while (p != null) {
            Product product = (Product) p.info;
            if (product.getPcode().equalsIgnoreCase(pcode)) {
                return product;
            }
            p = p.next;
        }
        return null;
    }

    public void deleteFirst() {
        if (!isEmpty()) {
            if (head.next == null) {
                head = tail = null;
            } else {
                head = head.next;
            }
        }
    }

    public void deleteLast() {
        Node current = head;
        if (isEmpty()) {
            System.out.println("List is empty!");
        } else if (head.next == null) {
            head = null;
        } else {
            while (current.next.next != null) {
                current = current.next;
            }
            current.next = null;
            tail = current;
        }
    }

    public int countElement() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    public void delNodeAtPos(int pos) {
        if (!isEmpty() && pos >= 0 && pos < countElement()) {
            Node p = head;
            int count = 0;
            if (pos == 0) {
                deleteFirst();
            } else if (pos == countElement() - 1) {
                deleteLast();
            } else {
                while (p != null) {
                    if (count == pos - 1) {
                        p.next = p.next.next;
                        return;
                    }
                    count++;
                    p = p.next;
                }
            }
        }
    }

    public void f6_deleteByPcode(String pcode) {
        Node p = head;
        int count = 0;
        while (p != null) {
            Product prd = (Product) p.info;
            if (prd.getPcode().equalsIgnoreCase(pcode)) {
                delNodeAtPos(count);
                break;
            }
            p = p.next;
            count++;
        }
    }

    public void f7_sortByPcodeAscending() {
        for (Node i = head; i.next != tail; i = i.next) {
            for (Node j = head; j != tail; j = j.next) {
                if (((Product) j.info).getPcode().compareTo(((Product) j.next.info).getPcode()) > 0) {
                    Object temp = j.info;
                    j.info = j.next.info;
                    j.next.info = temp;
                }
            }
        }
    }

    public void f8_inputAndAddToBegin() throws Exception {
        String pcode = Validate.getString("Enter pcode: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String name = Validate.getString("Enter name: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String maker = Validate.getString("Enter maker: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String unit = Validate.getString("Enter unit: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String category = Validate.getString("Enter category: ", "Error!", "^[a-zA-Z0-9 ]+$");
        int quantity = Validate.getInt("Enter quanity: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
        int saled;
        do {
            saled = Validate.getInt("Enter saled: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
            if (saled <= quantity) {
                break;
            } else {
                System.out.println("Enter saled again (Saled <= Quantity): ");
            }
        } while (true);
        double price = Validate.getDouble("Enter price: ", "Out of range!", "Invalid format!", 0, Double.MAX_VALUE);
        Product p = new Product(pcode, name, maker, unit, category, quantity, saled, price);
        addLast(p);
        System.out.println("Added first successfully!");
    }

    public void addFirst(Product x) {
        Node newNode = new Node(x);
        if (isEmpty()) {
            head = tail = newNode;
        } else {
            newNode.next = head;
            head = newNode;
        }

    }

    public void f9_addBeforePos(int pos) throws Exception {
        Node p = head;
        int count = 0;
        String pcode = Validate.getString("Enter pcode: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String name = Validate.getString("Enter name: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String maker = Validate.getString("Enter maker: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String unit = Validate.getString("Enter unit: ", "Error!", "^[a-zA-Z0-9 ]+$");
        String category = Validate.getString("Enter category: ", "Error!", "^[a-zA-Z0-9 ]+$");
        int quantity = Validate.getInt("Enter quanity: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
        int saled;
        do {
            saled = Validate.getInt("Enter saled: ", "Out of range!", "Invalid format!", 0, Integer.MAX_VALUE);
            if (saled <= quantity) {
                break;
            } else {
                System.out.println("Enter saled again (Saled <= Quantity): ");
            }
        } while (true);
        double price = Validate.getDouble("Enter price: ", "Out of range!", "Invalid format!", 0, Double.MAX_VALUE);
        Product x = new Product(pcode, name, maker, unit, category, quantity, saled, price);
        Node newNode = new Node(x);
        if (pos >= 0 && pos < countElement() - 1) {
            if (pos == 0) {
                addFirst(x);
            } else if (pos == countElement() - 1) {
                addLast(x);
            } else {
                while (p != null) {
                    if (count == pos - 2) {
                        System.out.println("Added successfully!");
                        newNode.next = p.next;
                        p.next = newNode;
                        return;
                    }
                    count++;
                    p = p.next;
                }
            }
        } else {
            System.out.println("Invalid position!");
        }
    }

    public void f10_deleteAtPosK(int pos) {
        if (!isEmpty() && pos >= 0 && pos < countElement()) {
            Node p = head;
            int count = 0;
            if (pos == 0) {
                deleteFirst();
            } else if (pos == countElement() - 1) {
                deleteLast();
            } else {
                while (p != null) {
                    if (count == pos - 1) {
                        System.out.println("Delete successfully!");
                        p.next = p.next.next;
                        return;
                    }
                    count++;
                    p = p.next;
                }
            }
        }
    }

    public void f11_searchByName(String pcode) {
        Node p = head;
        System.out.println(String.format("%-5s %-15s %-10s %-10s %-15s %-10s %-10s %-8s", "Pcode", "Name", "Maker", "Unit", "Category", "Quantity", "Saled", "Price"));
        while (p != null) {
            Product prd = (Product) p.info;
            if (prd.getName().equalsIgnoreCase(pcode)) {
                System.out.println(p.info.toString());
                break;
            }
            p = p.next;
        }
    }

    public void f12_searchOrderedByPcode(String pcode, CustomerList customerList, OrderList orderList) {
        Node p = orderList.head;
        Product product = f5_searchByPcode(pcode);
        if (product != null) {
            System.out.println("Product found: ");
            System.out.println(String.format("%-5s %-15s %-10s %-10s %-15s %-10s %-10s %-8s", "Pcode", "Name", "Maker", "Unit", "Category", "Quantity", "Saled", "Price"));
            System.out.println(product.toString());
            System.out.println("Customers ordered this product: ");
            boolean hasOrders = false;
            while (p != null) {
                Order order = (Order) p.info;
                if (order.getPcode().equalsIgnoreCase(pcode)) {
                    hasOrders = true;
                    Customer customer = customerList.f5_searchByCcode(order.getCcode());
                    if (customer != null) {
                        System.out.println(String.format("%-10s %-20s %-15s", "Ccode", "Name", "Phone Number"));
                        System.out.println(customer.toString());
                    }
                }
                p = p.next;
            }
            if (!hasOrders) {
                System.out.println("No customers have ordered this product.");
            }
        } else {
            System.out.println("Not found product with pcode: " + pcode);
        }
    }

}
