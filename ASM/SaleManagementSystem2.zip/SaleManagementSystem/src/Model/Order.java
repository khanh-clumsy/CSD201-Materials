/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author admin
 */
public class Order {

    private String pcode;
    private String ccode;
    private Date odate;
    private Date sdate;
    private int quantity;

    public Order() {
    }

    public Order(String pcode, String ccode, Date odate, Date sdate, int quantity) throws Exception {
        if (quantity > 0) {
            this.pcode = pcode;
            this.ccode = ccode;
            this.odate = odate;
            this.sdate = sdate;
            this.quantity = quantity;
        } else {
            throw new Exception("Quantity must >0!");
        }
    }

    public String getPcode() {
        return pcode;
    }

    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    public String getCcode() {
        return ccode;
    }

    public void setCcode(String ccode) {
        this.ccode = ccode;
    }

    public String getOdate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(odate);
    }

    public void setOdate(Date odate) {
        this.odate = odate;
    }

    public String getSdate() {
        if (sdate != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format(sdate);
        } else {
            return "Not shipped";
        }
    }

    public void setSdate(Date sdate) {
        this.sdate = sdate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
