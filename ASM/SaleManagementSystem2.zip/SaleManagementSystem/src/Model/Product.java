package Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class Product {

    private String pcode;
    private String name;
    private String maker;
    private String unit;
    private String category;
    private int quantity;
    private int saled;
    private double price;

    public Product() {
    }

    public Product(String pcode, String name, String maker, String unit, String category, int quantity, int saled, double price) throws Exception {
        if (saled < quantity) {
            this.pcode = pcode;
            this.name = name;
            this.maker = maker;
            this.unit = unit;
            this.category = category;
            this.quantity = quantity;
            this.saled = saled;
            this.price = price;
        } else {
            throw new Exception("Saled must less or equal than quantity!");
        }
    }

    public String getPcode() {
        return pcode;
    }

    public void setPcode(String pcode) {
        this.pcode = pcode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMaker() {
        return maker;
    }

    public void setMaker(String maker) {
        this.maker = maker;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getSaled() {
        return saled;
    }

    public void setSaled(int saled) {
        this.saled = saled;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("%-5s %-15s %-10s %-10s %-15s %-10d %-10d %-8.2f", this.getPcode(), 
                this.getName(), this.getMaker(), this.getUnit(), this.getCategory(), 
                this.getQuantity(), this.getSaled(), this.getPrice());
                
    }

}
