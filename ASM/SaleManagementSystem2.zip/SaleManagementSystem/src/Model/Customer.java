package Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author admin
 */
public class Customer {

    private String ccode;
    private String name;
    private String phone;

    public Customer() {
    }

    private boolean isValidPhone(String phone) {
        return phone.matches("^[0-9]+$");
    }

    public Customer(String ccode, String name, String phone) throws Exception {
        if (isValidPhone(phone)) {
            this.ccode = ccode;
            this.name = name;
            this.phone = phone;
        } else {
            throw new Exception("Invalid phone number!");
        }
    }

    public String getCcode() {
        return ccode;
    }

    public void setCcode(String ccode) {
        this.ccode = ccode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) throws Exception {
        if (isValidPhone(phone)) {
            this.phone = phone;
        } else {
            throw new Exception("Invalid phone number!");
        }
    }

    @Override
    public String toString() {
        return String.format("%-10s %-20s %-15s", this.getCcode(), this.getName(), this.getPhone());
    }

}
