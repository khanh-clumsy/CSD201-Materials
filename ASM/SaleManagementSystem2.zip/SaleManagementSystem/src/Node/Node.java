/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Node;

import Model.Customer;

/**
 *
 * @author admin
 */
public class Node {
    public Object info;
    public Node next;

    public Node() {
    }

    public Node(Object inf, Node next) {
        this.info = inf;
        this.next = next;
    }

    public Node(Object inf) {
        this(inf, null);
    }
}
